import streamlit as st
from utils.file_handler import extract_text
from engine.summarizer import generate_summary
from engine.qa import answer_question
from engine.challenge import generate_questions, evaluate_answers

st.set_page_config(page_title="Smart Assistant", layout="wide")

st.title("📚 Smart Assistant for Research Summarization")

uploaded_file = st.file_uploader("Upload a PDF or TXT file", type=["pdf", "txt"])
if uploaded_file:
    text = extract_text(uploaded_file)
    st.session_state["document_text"] = text

    st.subheader("📄 Auto Summary")
    summary = generate_summary(text)
    st.write(summary)

    mode = st.radio("Choose a mode:", ["Ask Anything", "Challenge Me"])

    if mode == "Ask Anything":
        user_question = st.text_input("Ask a question based on the document:")
        if user_question:
            answer, justification = answer_question(text, user_question)
            st.markdown(f"**Answer:** {answer}")
            st.markdown(f"**Justification:** {justification}")

    elif mode == "Challenge Me":
        st.subheader("🧠 Test Your Understanding")
        if "challenge" not in st.session_state:
            st.session_state["challenge"] = generate_questions(text)

        answers = []
        for i, q in enumerate(st.session_state["challenge"]):
            user_ans = st.text_input(f"Q{i+1}: {q}", key=f"q{i}")
            answers.append(user_ans)

        if st.button("Evaluate My Answers"):
            feedback = evaluate_answers(st.session_state["challenge"], answers, text)
            for i, f in enumerate(feedback):
                st.markdown(f"**Q{i+1} Feedback:** {f}")
